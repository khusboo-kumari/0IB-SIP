document.getElementById("btn").onclick=function(){
    c = document.getElementById("celcius").value;
    c = Number(c)

    f = (9*c+160)/5;
    document.getElementById("fahrenheit").innerHTML = `${c}°C  = ${f}°F` 
    
}

document.getElementById("btn1").onclick=function(){
    f = document.getElementById("celcius2").value;
    f = Number(f)

    f = (9*c+160)/5;
    document.getElementById("fahrenheit2").innerHTML = `${f}°F  = ${c}°C` 
    
}